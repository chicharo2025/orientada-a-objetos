﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using taller.Data;
using taller.Models;

namespace taller.Controllers
{
    public class DetalleVentasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DetalleVentasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: DetalleVentas
        public async Task<IActionResult> Index()
        {
            var detalles = await _context.DetalleVenta
                .Include(d => d.Producto)
                .Include(d => d.Venta)
                .ToListAsync();

            return View(detalles);
        }

        // GET: DetalleVentas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var detalle = await _context.DetalleVenta
                .Include(d => d.Producto)
                .Include(d => d.Venta)
                .FirstOrDefaultAsync(m => m.DetalleVentaId == id);

            if (detalle == null) return NotFound();

            return View(detalle);
        }

        // GET: DetalleVentas/Create
        public IActionResult Create(int ventaId)
        {
            ViewData["VentaId"] = new SelectList(_context.Venta, "VentaId", "VentaId", ventaId);
            ViewData["ProductoId"] = new SelectList(_context.Producto, "ProductoId", "Nombre");

            var detalle = new DetalleVenta
            {
                VentaId = ventaId
            };

            return View(detalle);
        }

        // POST: DetalleVentas/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DetalleVentaId,VentaId,ProductoId,Cantidad,Subtotal")] DetalleVenta detalleVenta)
        {
            if (ModelState.IsValid)
            {
                _context.Add(detalleVenta);
                await _context.SaveChangesAsync();

                // Redirige a agregar otro producto a la misma venta
                return RedirectToAction("Create", new { ventaId = detalleVenta.VentaId });
            }

            ViewData["VentaId"] = new SelectList(_context.Venta, "VentaId", "VentaId", detalleVenta.VentaId);
            ViewData["ProductoId"] = new SelectList(_context.Producto, "ProductoId", "Nombre", detalleVenta.ProductoId);
            return View(detalleVenta);
        }

        // GET: DetalleVentas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var detalle = await _context.DetalleVenta.FindAsync(id);
            if (detalle == null) return NotFound();

            ViewData["VentaId"] = new SelectList(_context.Venta, "VentaId", "VentaId", detalle.VentaId);
            ViewData["ProductoId"] = new SelectList(_context.Producto, "ProductoId", "Nombre", detalle.ProductoId);
            return View(detalle);
        }

        // POST: DetalleVentas/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DetalleVentaId,VentaId,ProductoId,Cantidad,Subtotal")] DetalleVenta detalleVenta)
        {
            if (id != detalleVenta.DetalleVentaId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(detalleVenta);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetalleVentaExists(detalleVenta.DetalleVentaId))
                        return NotFound();
                    else
                        throw;
                }

                return RedirectToAction(nameof(Index));
            }

            ViewData["VentaId"] = new SelectList(_context.Venta, "VentaId", "VentaId", detalleVenta.VentaId);
            ViewData["ProductoId"] = new SelectList(_context.Producto, "ProductoId", "Nombre", detalleVenta.ProductoId);
            return View(detalleVenta);
        }

        // GET: DetalleVentas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var detalle = await _context.DetalleVenta
                .Include(d => d.Producto)
                .Include(d => d.Venta)
                .FirstOrDefaultAsync(m => m.DetalleVentaId == id);

            if (detalle == null) return NotFound();

            return View(detalle);
        }

        // POST: DetalleVentas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var detalle = await _context.DetalleVenta.FindAsync(id);
            if (detalle != null)
            {
                _context.DetalleVenta.Remove(detalle);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DetalleVentaExists(int id)
        {
            return _context.DetalleVenta.Any(e => e.DetalleVentaId == id);
        }
    }
}
