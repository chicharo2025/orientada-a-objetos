﻿using System;

namespace bancaria
{
    // La clase CuentaBancaria se mantiene sin cambios, solo se actualiza la clase Program.
    public class CuentaBancaria
    {
        // Propiedades de la cuenta bancaria (los mismos que antes)
        public int NumeroCuenta { get; private set; }
        public int DniCliente { get; private set; }
        public double Saldo { get; private set; }
        public double InteresAnual { get; set; }
        public string Titular { get; private set; }

        // Constructor de la clase (los mismos que antes)
        public CuentaBancaria(int numeroCuenta, int dniCliente, double saldo, double interesAnual, string titular)
        {
            NumeroCuenta = numeroCuenta;
            DniCliente = dniCliente;
            Saldo = saldo;
            InteresAnual = interesAnual;
            Titular = titular;
        }

        // Métodos de la clase (los mismos que antes)
        public void Depositar(double cantidad)
        {
            if (cantidad > 0)
            {
                Saldo += cantidad;
                Console.WriteLine($"Depósito de {cantidad:C} realizado. Nuevo saldo: {Saldo:C}");
            }
            else
            {
                Console.WriteLine("La cantidad a depositar debe ser mayor que cero.");
            }
        }

        public void Retirar(double cantidad)
        {
            if (cantidad > 0)
            {
                if (Saldo >= cantidad)
                {
                    Saldo -= cantidad;
                    Console.WriteLine($"Retiro de {cantidad:C} realizado. Nuevo saldo: {Saldo:C}");
                }
                else
                {
                    Console.WriteLine("Saldo insuficiente para realizar el retiro.");
                }
            }
            else
            {
                Console.WriteLine("La cantidad a retirar debe ser mayor que cero.");
            }
        }

        public void CalcularInteres()
        {
            double interesCalculado = (Saldo * InteresAnual) / 100;
            Saldo += interesCalculado;
            Console.WriteLine($"Interés anual de {interesCalculado:C} aplicado. Nuevo saldo: {Saldo:C}");
        }

        public void ActualizarSaldo()
        {
            double interesDiario = (Saldo * (InteresAnual / 365)) / 100;
            Saldo += interesDiario;
            Console.WriteLine($"Interés diario de {interesDiario:C} aplicado. Nuevo saldo: {Saldo:C}");
        }

        public void MostrarInformacion()
        {
            Console.WriteLine("--- Información de la Cuenta ---");
            Console.WriteLine($"Titular: {Titular}");
            Console.WriteLine($"Número de cuenta: {NumeroCuenta}");
            Console.WriteLine($"DNI del cliente: {DniCliente}");
            Console.WriteLine($"Saldo actual: {Saldo:C}");
            Console.WriteLine($"Interés anual: {InteresAnual}%");
            Console.WriteLine("-------------------------------");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // --- NUEVA LÓGICA: Solicitar datos al usuario para crear la cuenta ---
            Console.WriteLine("--- Creación de Nueva Cuenta Bancaria ---");

            Console.Write("Ingrese el nombre del titular: ");
            string titular = Console.ReadLine();

            int numeroCuenta;
            Console.Write("Ingrese el número de cuenta: ");
            while (!int.TryParse(Console.ReadLine(), out numeroCuenta))
            {
                Console.WriteLine("Número de cuenta inválido. Intente de nuevo: ");
            }

            int dniCliente;
            Console.Write("Ingrese el DNI del cliente: ");
            while (!int.TryParse(Console.ReadLine(), out dniCliente))
            {
                Console.WriteLine("DNI inválido. Intente de nuevo: ");
            }

            double saldoInicial;
            Console.Write("Ingrese el saldo inicial: ");
            while (!double.TryParse(Console.ReadLine(), out saldoInicial))
            {
                Console.WriteLine("Saldo inválido. Intente de nuevo: ");
            }

            double interesAnual;
            Console.Write("Ingrese el interés anual (%): ");
            while (!double.TryParse(Console.ReadLine(), out interesAnual))
            {
                Console.WriteLine("Interés inválido. Intente de nuevo: ");
            }

            // Crear la cuenta bancaria con los datos ingresados por el usuario.
            CuentaBancaria cuenta = new CuentaBancaria(numeroCuenta, dniCliente, saldoInicial, interesAnual, titular);

            Console.WriteLine("\n¡Cuenta creada con éxito! Presione cualquier tecla para continuar al menú.");
            Console.ReadKey();

            // --- Lógica del menú principal (se mantiene igual) ---
            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                Console.WriteLine("=== Menú de la Cuenta Bancaria ===");
                Console.WriteLine("1. Depositar dinero");
                Console.WriteLine("2. Retirar dinero");
                Console.WriteLine("3. Calcular interés diario");
                Console.WriteLine("4. Mostrar información de la cuenta");
                Console.WriteLine("5. Salir");
                Console.Write("Seleccione una opción (1-5): ");

                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Console.Write("Ingrese la cantidad a depositar: ");
                        if (double.TryParse(Console.ReadLine(), out double deposito))
                        {
                            cuenta.Depositar(deposito);
                        }
                        else
                        {
                            Console.WriteLine("Entrada inválida.");
                        }
                        break;

                    case "2":
                        Console.Write("Ingrese la cantidad a retirar: ");
                        if (double.TryParse(Console.ReadLine(), out double retiro))
                        {
                            cuenta.Retirar(retiro);
                        }
                        else
                        {
                            Console.WriteLine("Entrada inválida.");
                        }
                        break;

                    case "3":
                        cuenta.ActualizarSaldo();
                        break;

                    case "4":
                        cuenta.MostrarInformacion();
                        break;

                    case "5":
                        salir = true;
                        Console.WriteLine("Gracias por usar el sistema bancario.");
                        break;

                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        break;
                }

                if (!salir)
                {
                    Console.WriteLine("\nPresione cualquier tecla para continuar...");
                    Console.ReadKey();
                }
            }
        }
    }
}
