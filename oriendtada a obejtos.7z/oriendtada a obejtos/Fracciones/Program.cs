﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FraccionesPOO
{
    // A. Crea una clase Racional que permita trabajar con números racionales (fracciones).
    //    Incluye los siguientes métodos: constructores, accesores, leer(), suma, resta, multiplicación, división.
    public class Racional
    {
        // Campos privados para encapsular los datos de la fracción
        private int numerador;
        private int denominador;

        // -----------------------
        // CONSTRUCTORES
        // -----------------------

        // 1. Constructor por defecto: Inicializa la fracción a 0/1
        public Racional()
        {
            this.numerador = 0;
            this.denominador = 1;
        }

        // 2. Constructor parametrizado: Inicializa la fracción con valores dados
        public Racional(int num, int den)
        {
            // Validar que el denominador no sea cero
            if (den == 0)
            {
                throw new ArgumentException("El denominador no puede ser cero.");
            }
            this.numerador = num;
            this.denominador = den;
        }

        // -----------------------
        // ACCESORES (PROPIEDADES)
        // -----------------------

        // Propiedad para acceder al numerador
        public int Numerador
        {
            get { return this.numerador; }
            set { this.numerador = value; }
        }

        // Propiedad para acceder al denominador, con validación
        public int Denominador
        {
            get { return this.denominador; }
            set
            {
                if (value == 0)
                {
                    throw new ArgumentException("El denominador no puede ser cero.");
                }
                this.denominador = value;
            }
        }

        // -----------------------
        // MÉTODOS DE LECTURA Y VISUALIZACIÓN
        // -----------------------

        // Método para leer la fracción desde la consola
        public void Leer()
        {
            Console.Write("Ingrese el numerador: ");
            this.numerador = int.Parse(Console.ReadLine());

            // Leer el denominador y validar que no sea cero
            int tempDenominador;
            do
            {
                Console.Write("Ingrese el denominador: ");
                tempDenominador = int.Parse(Console.ReadLine());
                if (tempDenominador == 0)
                {
                    Console.WriteLine("Error: El denominador no puede ser cero. Intente de nuevo.");
                }
            } while (tempDenominador == 0);
            this.denominador = tempDenominador;
        }

        // Método para mostrar la fracción en formato n/d
        public override string ToString()
        {
            return $"{this.numerador}/{this.denominador}";
        }

        // -----------------------
        // MÉTODOS DE OPERACIONES ARITMÉTICAS
        // -----------------------

        // Método para sumar otra fracción y devolver un nuevo objeto Racional
        public Racional Suma(Racional otraFraccion)
        {
            int nuevoNumerador = (this.numerador * otraFraccion.denominador) + (otraFraccion.numerador * this.denominador);
            int nuevoDenominador = this.denominador * otraFraccion.denominador;
            return new Racional(nuevoNumerador, nuevoDenominador);
        }

        // Método para restar otra fracción y devolver un nuevo objeto Racional
        public Racional Resta(Racional otraFraccion)
        {
            int nuevoNumerador = (this.numerador * otraFraccion.denominador) - (otraFraccion.numerador * this.denominador);
            int nuevoDenominador = this.denominador * otraFraccion.denominador;
            return new Racional(nuevoNumerador, nuevoDenominador);
        }

        // Método para multiplicar por otra fracción y devolver un nuevo objeto Racional
        public Racional Multiplicacion(Racional otraFraccion)
        {
            int nuevoNumerador = this.numerador * otraFraccion.numerador;
            int nuevoDenominador = this.denominador * otraFraccion.denominador;
            return new Racional(nuevoNumerador, nuevoDenominador);
        }

        // Método para dividir por otra fracción y devolver un nuevo objeto Racional
        public Racional Division(Racional otraFraccion)
        {
            int nuevoNumerador = this.numerador * otraFraccion.denominador;
            int nuevoDenominador = this.denominador * otraFraccion.numerador;
            return new Racional(nuevoNumerador, nuevoDenominador);
        }
    }

    // -----------------------
    // PROGRAMA PRINCIPAL
    // -----------------------
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Calculadora de Fracciones (POO) ---");

            // Creamos dos objetos de la clase Racional
            Racional fraccion1 = new Racional();
            Racional fraccion2 = new Racional();

            Console.WriteLine("Ingrese los datos de la primera fracción:");
            fraccion1.Leer();

            Console.WriteLine("\nIngrese los datos de la segunda fracción:");
            fraccion2.Leer();

            Console.WriteLine($"\nFracción 1: {fraccion1}");
            Console.WriteLine($"Fracción 2: {fraccion2}");

            // Realizamos las operaciones y almacenamos los resultados en nuevos objetos
            Racional resultadoSuma = fraccion1.Suma(fraccion2);
            Racional resultadoResta = fraccion1.Resta(fraccion2);
            Racional resultadoMultiplicacion = fraccion1.Multiplicacion(fraccion2);
            Racional resultadoDivision = fraccion1.Division(fraccion2);

            // Mostramos los resultados
            Console.WriteLine("\n--- Resultados ---");
            Console.WriteLine($"Suma: {resultadoSuma}");
            Console.WriteLine($"Resta: {resultadoResta}");
            Console.WriteLine($"Multiplicación: {resultadoMultiplicacion}");
            Console.WriteLine($"División: {resultadoDivision}");

            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}