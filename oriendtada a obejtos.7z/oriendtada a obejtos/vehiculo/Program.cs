﻿using System;
using System.Collections.Generic;

namespace Vehiculo
{
    /// <summary>
    /// Representa un Motor con su potencia y estado de encendido.
    /// </summary>
    public class Motor
    {
        public double Potencia { get; private set; }
        public bool Encendido { get; private set; }

        public Motor(double potencia)
        {
            this.Potencia = potencia;
            this.Encendido = false; // El motor comienza apagado
        }

        public void Encender()
        {
            if (!Encendido)
            {
                Encendido = true;
                Console.WriteLine("El motor se ha encendido.");
            }
            else
            {
                Console.WriteLine("El motor ya está encendido.");
            }
        }

        public void Apagar()
        {
            if (Encendido)
            {
                Encendido = false;
                Console.WriteLine("El motor se ha apagado.");
            }
            else
            {
                Console.WriteLine("El motor ya está apagado.");
            }
        }
    }

    /// <summary>
    /// Representa una Rueda con su tipo y presión.
    /// </summary>
    public class Rueda
    {
        public string TipoRueda { get; set; }
        public double PresionActual { get; private set; }

        private const double PresionMaxima = 35.0;
        private const double PresionMinima = 10.0;

        public Rueda(string tipoRueda, double presionInicial)
        {
            this.TipoRueda = tipoRueda;
            if (presionInicial >= PresionMinima && presionInicial <= PresionMaxima)
            {
                this.PresionActual = presionInicial;
            }
            else
            {
                this.PresionActual = PresionMinima;
            }
        }

        public void Inflar()
        {
            double nuevaPresion = this.PresionActual + 5.0;

            if (nuevaPresion <= PresionMaxima)
            {
                this.PresionActual = nuevaPresion;
                Console.WriteLine($"Rueda inflada. Nueva presión: {this.PresionActual} PSI");
            }
            else
            {
                this.PresionActual = PresionMaxima;
                Console.WriteLine($"La rueda ya está al máximo. Presión actual: {this.PresionActual} PSI");
            }
        }
    }

    /// <summary>
    /// Representa una Ventana que puede estar abierta o cerrada.
    /// </summary>
    public class Ventana
    {
        public bool Abierta { get; private set; }

        public Ventana()
        {
            this.Abierta = false; // La ventana comienza cerrada
        }

        public void Subir()
        {
            if (Abierta)
            {
                Abierta = false;
                Console.WriteLine("La ventana se ha subido.");
            }
            else
            {
                Console.WriteLine("La ventana ya está subida.");
            }
        }

        public void Bajar()
        {
            if (!Abierta)
            {
                Abierta = true;
                Console.WriteLine("La ventana se ha bajado.");
            }
            else
            {
                Console.WriteLine("La ventana ya está bajada.");
            }
        }
    }

    /// <summary>
    /// Representa una Puerta, que contiene una Ventana.
    /// </summary>
    public class Puerta
    {
        public string Posicion { get; private set; }
        public bool Abierta { get; private set; }
        public Ventana MiVentana { get; private set; }

        public Puerta(string posicion)
        {
            this.Posicion = posicion;
            this.Abierta = false; // La puerta comienza cerrada
            this.MiVentana = new Ventana(); // Cada puerta tiene su propia ventana
        }

        public void Abrir()
        {
            if (!Abierta)
            {
                Abierta = true;
                Console.WriteLine($"La puerta {Posicion} se ha abierto.");
            }
            else
            {
                Console.WriteLine($"La puerta {Posicion} ya está abierta.");
            }
        }

        public void Cerrar()
        {
            if (Abierta)
            {
                Abierta = false;
                Console.WriteLine($"La puerta {Posicion} se ha cerrado.");
            }
            else
            {
                Console.WriteLine($"La puerta {Posicion} ya está cerrada.");
            }
        }
    }

    /// <summary>
    /// La clase Coche, que es el punto central del programa y
    /// contiene los demás componentes (Motor, Ruedas y Puertas).
    /// </summary>
    public class Coche
    {
        public string Marca { get; set; }
        public Motor MiMotor { get; private set; }
        public List<Rueda> Ruedas { get; private set; }
        public List<Puerta> Puertas { get; private set; }

        public Coche(string marca, double potenciaMotor, string tipoRueda, double presionInicial)
        {
            this.Marca = marca;
            this.MiMotor = new Motor(potenciaMotor);

            // Creamos las 4 ruedas
            this.Ruedas = new List<Rueda>();
            for (int i = 0; i < 4; i++)
            {
                this.Ruedas.Add(new Rueda(tipoRueda, presionInicial));
            }

            // Creamos las 2 puertas
            this.Puertas = new List<Puerta>
            {
                new Puerta("delantera izquierda"),
                new Puerta("delantera derecha")
            };
        }

        // Métodos de alto nivel para controlar el coche.
        public void Arrancar()
        {
            Console.WriteLine("\nIntento de arranque del coche...");
            MiMotor.Encender();
        }

        public void Detener()
        {
            Console.WriteLine("\nDeteniendo el coche...");
            MiMotor.Apagar();
        }

        public void AbrirPuerta(int indicePuerta)
        {
            if (indicePuerta >= 0 && indicePuerta < Puertas.Count)
            {
                Puertas[indicePuerta].Abrir();
            }
            else
            {
                Console.WriteLine("Índice de puerta no válido.");
            }
        }

        public void CerrarPuerta(int indicePuerta)
        {
            if (indicePuerta >= 0 && indicePuerta < Puertas.Count)
            {
                Puertas[indicePuerta].Cerrar();
            }
            else
            {
                Console.WriteLine("Índice de puerta no válido.");
            }
        }

        public void InflarTodasLasRuedas()
        {
            Console.WriteLine("\nInflando todas las ruedas...");
            foreach (Rueda r in Ruedas)
            {
                r.Inflar();
            }
        }

        public void MostrarEstadoCompleto()
        {
            Console.WriteLine($"\n--- Estado del Coche: {this.Marca} ---");
            Console.WriteLine($"Motor: {(this.MiMotor.Encendido ? "Encendido" : "Apagado")}");

            for (int i = 0; i < Ruedas.Count; i++)
            {
                Console.WriteLine($"Rueda {i + 1}: Presión '{Ruedas[i].PresionActual} PSI'");
            }

            for (int i = 0; i < Puertas.Count; i++)
            {
                Console.WriteLine($"Puerta {Puertas[i].Posicion}: {(Puertas[i].Abierta ? "Abierta" : "Cerrada")}");
                Console.WriteLine($"  Ventana: {(Puertas[i].MiVentana.Abierta ? "Abierta" : "Cerrada")}");
            }
            Console.WriteLine("-------------------------------------");
        }
    }

    /// <summary>
    /// El punto de entrada del programa.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Coche miCoche = new Coche(marca: "Nissan", potenciaMotor: 200, tipoRueda: "Deportiva", presionInicial: 25.0);

            Console.WriteLine("¡Bienvenido al simulador de coche!\n");
            miCoche.MostrarEstadoCompleto();

            Console.WriteLine("\n--- Realizando algunas acciones ---");
            miCoche.Arrancar(); // Enciende el motor
            miCoche.AbrirPuerta(0); // Abre la puerta delantera izquierda
            miCoche.Puertas[0].MiVentana.Bajar(); // Baja la ventana de esa puerta
            miCoche.InflarTodasLasRuedas(); // Infla todas las ruedas

            Console.WriteLine("\n--- Nuevo estado del coche ---");
            miCoche.MostrarEstadoCompleto();

            miCoche.Detener(); // Apaga el motor

            Console.WriteLine("\nPresiona cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
